#!/bin/sh
cd "$(dirname "$0")" || exit 1
CONTROL_URL=http://127.0.0.1:8765
export PATH="$HOME/.local/bin:/usr/local/bin:/opt/homebrew/bin:$PATH"

if curl --noproxy '*' --silent --fail --max-time 2 "$CONTROL_URL/api/health" | grep -q 'local-supabase-control'; then
  open "$CONTROL_URL"
  exit 0
fi

if lsof -nP -iTCP:8765 -sTCP:LISTEN >/dev/null 2>&1; then
  echo '8765 端口已被其他程序使用，无法启动控制台。'
  exit 1
fi

nohup python3 scripts/service-control.py > /tmp/local-supabase-control.log 2>&1 < /dev/null &
attempt=0
while [ "$attempt" -lt 30 ]; do
  if curl --noproxy '*' --silent --fail --max-time 1 "$CONTROL_URL/api/health" | grep -q 'local-supabase-control'; then
    open "$CONTROL_URL"
    exit 0
  fi
  attempt=$((attempt + 1))
  sleep 1
done
echo '控制台启动失败。请检查 /tmp/local-supabase-control.log。'
exit 1
