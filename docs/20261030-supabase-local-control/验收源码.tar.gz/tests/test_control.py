import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts/service-control.py'


def result(stdout='', ok=True, kind='exit', detail='test failure', code=1):
    return dict(ok=ok, stdout=stdout, code=0 if ok else code, kind=None if ok else kind, detail=detail)


def containers(status='Up 3 minutes (healthy)', project='lemon-kids-local'):
    return '\n'.join(json.dumps({'Names': f'supabase_{name}_{project}', 'Status': status}) for name in
                     ('db','kong','auth','rest','realtime','storage','studio','inbucket','pg_meta','edge_runtime'))


class ControlTest(unittest.TestCase):
    def setUp(self):
        spec = importlib.util.spec_from_file_location('control', SCRIPT)
        self.c = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.c)
        self.calls = []
        self.mounts = f'/dev/a on {self.c.DISK} (tuxera_ntfs)\n/dev/b on {self.c.RUNTIME} (hfs)'

    def fake(self, args, timeout=8):
        self.calls.append(args)
        if args == ['mount']:
            return result(self.mounts)
        if args[0].endswith('/colima'):
            return result()
        if 'info' in args:
            return result('28.0.0')
        if '--filter' in args:
            return result(containers())
        if 'ps' in args:
            return result()
        return result()

    def test_project_filter_and_metadata(self):
        with patch.object(self.c, 'command', side_effect=self.fake):
            snap = self.c.probe_now()
        self.assertEqual(snap['items']['supabase']['state'], 'running')
        self.assertIn('name=^supabase_.*_lemon-kids-local$', self.calls[-1])
        self.assertEqual(self.c.META['studio'], 'http://127.0.0.1:54423')

    def test_foreign_containers_excluded_even_if_docker_filter_fails(self):
        rows, state = self.c.parse_containers(containers(project='local-supabase-service'))
        self.assertEqual(state, 'stopped')
        self.assertTrue(all(row['status'] == '未创建' for row in rows))

    def test_health_states_and_missing(self):
        for status, expected in [('Up 1 minute (healthy)','running'),('Up 2 minutes','running'),
                                 ('Up 1 minute (health: starting)','starting'),('Up 1 minute (unhealthy)','error'),
                                 ('Exited (1) 1 minute ago','stopped'),('Restarting (1)','error'),
                                 ('Up 2 minutes (Paused)','error')]:
            with self.subTest(status=status):
                self.assertEqual(self.c.parse_containers(containers(status))[1], expected)
        partial = containers().splitlines()[:-1]
        self.assertEqual(self.c.parse_containers('\n'.join(partial))[1], 'partial')
        self.assertEqual(self.c.parse_containers('')[1], 'stopped')

    def test_timeout_history_recovery(self):
        with patch.object(self.c, 'command', side_effect=self.fake):
            initial = self.c.probe_now()
        def timeout(args, timeout=8):
            if '--filter' in args:
                return result(ok=False, kind='timeout', code=None, detail='响应超时（8 秒）')
            return self.fake(args, timeout)
        with patch.object(self.c, 'command', side_effect=timeout):
            failed = self.c.probe_now()
        item = failed['items']['supabase']
        self.assertEqual(item['state'], 'unknown')
        self.assertEqual(item['last_success']['state'], 'running')
        self.assertEqual(item['error']['kind'], 'timeout')
        self.assertEqual(failed['containers'], initial['containers'])
        self.assertEqual(failed['containers_at'], initial['containers_at'])
        self.assertFalse(failed['containers_current'])
        with patch.object(self.c, 'command', side_effect=self.fake):
            recovered = self.c.probe_now()
        self.assertIsNone(recovered['items']['supabase']['error'])
        self.assertTrue(recovered['containers_current'])

    def test_first_failure_and_upstream_unknown(self):
        with patch.object(self.c, 'command', return_value=result(ok=False, kind='timeout', code=None)):
            snap = self.c.probe_now()
        self.assertTrue(all(item['state'] == 'unknown' for item in snap['items'].values()))
        self.assertTrue(all(item['last_success'] is None for item in snap['items'].values()))
        self.assertEqual(snap['containers'], [])

    def test_confirmed_stopped_saved_in_history(self):
        def stopped(args, timeout=8):
            return result('') if '--filter' in args else self.fake(args, timeout)
        with patch.object(self.c, 'command', side_effect=stopped):
            snap = self.c.probe_now()
        self.assertEqual(snap['items']['supabase']['last_success']['state'], 'stopped')

    def test_bad_json_is_unknown_and_preserves_snapshot(self):
        with patch.object(self.c, 'command', side_effect=self.fake):
            before = self.c.probe_now()
        for output in ('not json', '{}', '[]', 'null', '{"Names":4,"Status":"Up"}'):
            def invalid(args, timeout=8):
                return result(output) if '--filter' in args else self.fake(args, timeout)
            with patch.object(self.c, 'command', side_effect=invalid):
                after = self.c.probe_now()
            self.assertEqual(after['items']['supabase']['error']['kind'], 'parse')
            self.assertEqual(after['items']['docker']['state'], 'running')
            self.assertEqual(after['containers'], before['containers'])

    def test_colima_explicit_stopped_only(self):
        for detail, expected in [('colima is not running', 'stopped'), ('permission denied', 'unknown')]:
            def failing(args, timeout=8):
                return result(ok=False, detail=detail) if args[0].endswith('/colima') else self.fake(args, timeout)
            with patch.object(self.c, 'command', side_effect=failing):
                snap = self.c.probe_now()
            self.assertEqual(snap['items']['colima']['state'], expected)

    def test_mount_missing_is_unavailable_not_unobserved_stopped(self):
        self.mounts = ''
        with patch.object(self.c, 'command', side_effect=self.fake):
            snap = self.c.probe_now()
        self.assertEqual(snap['items']['disk']['state'], 'stopped')
        self.assertEqual(snap['items']['supabase']['state'], 'unavailable')
        self.assertIsNone(snap['items']['supabase']['last_success'])

    def test_single_probe_for_concurrent_http_requests(self):
        started, release = threading.Event(), threading.Event()
        def slow_probe():
            started.set()
            release.wait(3)
            return {k:self.c.observation('running') for k in self.c.IDS}, []
        with patch.object(self.c, 'probe', side_effect=slow_probe) as mocked:
            self.c.status()
            self.assertTrue(started.wait(1))
            threads = [threading.Thread(target=self.c.status) for _ in range(20)]
            start = time.monotonic()
            for thread in threads: thread.start()
            for thread in threads: thread.join(1)
            self.assertLess(time.monotonic() - start, 1)
            self.assertEqual(mocked.call_count, 1)
            self.assertTrue(self.c.status()['checking'])
            release.set()
            for _ in range(100):
                if not self.c.CHECKING: break
                time.sleep(.01)
            self.assertFalse(self.c.CHECKING)
            self.c.status()
            self.assertEqual(mocked.call_count, 1)

    def test_command_timeout_and_redaction(self):
        exc = subprocess.TimeoutExpired(['x'], 8, stderr=b'password=do-not-show')
        with patch.object(self.c.subprocess, 'run', side_effect=exc):
            response = self.c.command(['x'])
        self.assertEqual(response['kind'], 'timeout')
        self.assertNotIn('do-not-show', response['detail'])
        with patch.object(self.c.subprocess, 'run', side_effect=OSError('missing')):
            self.assertEqual(self.c.command(['x'])['kind'], 'os')

    def test_redaction(self):
        raw = 'password=hunter token=abc "SERVICE_ROLE_KEY": "xyz" Bearer qwerty postgres://user:pass@localhost/db eyJabcdef.abcdef.abcdef sb_secret_abcdef'
        clean = self.c.redact(raw)
        for secret in ('hunter','abc','xyz','qwerty','user:pass','eyJabcdef','sb_secret_abcdef'):
            self.assertNotIn(secret, clean)
        self.assertLessEqual(len(self.c.redact('x'*2000)), 1200)

    def config(self, project=None):
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        self.c.WORKDIR = Path(folder.name)
        (self.c.WORKDIR/'supabase').mkdir()
        (self.c.WORKDIR/'supabase/config.toml').write_text(f'project_id = "{project or self.c.PROJECT}"\n' +
            '\n'.join(f'[{section}]\nport = {port}\n' for section, port in [('api',54421),('db',54422),('studio',54423),('local_smtp',54424)]))

    def test_project_and_port_validation(self):
        self.config('local-supabase-service')
        with self.assertRaisesRegex(RuntimeError, 'project_id'):
            self.c.supabase_args('start')
        self.config()
        path = self.c.WORKDIR/'supabase/config.toml'
        path.write_text(path.read_text().replace('54421','54321'))
        with self.assertRaisesRegex(RuntimeError, '端口'):
            self.c.supabase_args('start')

    def test_supabase_commands_always_explicit_workdir_and_keep_data(self):
        self.config()
        for action in ('start','stop'):
            args = self.c.supabase_args(action)
            self.assertEqual(args[:4], ['supabase',action,'--workdir',str(self.c.WORKDIR)])
            self.assertNotIn('--no-backup', args)
            self.assertNotIn('--all', args)

    def test_start_only_lemon_kids(self):
        self.config()
        count = 0
        def stopped(args, timeout=8):
            nonlocal count
            if '--filter' in args:
                count += 1
                return result('')
            return self.fake(args, timeout)
        with patch.object(self.c, 'command', side_effect=stopped), patch.object(Path, 'is_dir', return_value=True):
            self.c.work('start')
        self.assertIsNone(self.c.JOB['error'])
        mutations = [args for args in self.calls if args[0] == 'supabase']
        self.assertEqual(mutations, [self.c.supabase_args('start')])
        self.assertFalse(any('start' in args and args[0].endswith('/colima') for args in self.calls))

    def test_unknown_never_restarts_colima(self):
        self.config()
        def timeout(args, timeout=8):
            if args[0].endswith('/colima'):
                return result(ok=False, kind='timeout', code=None, detail='响应超时')
            return self.fake(args, timeout)
        with patch.object(self.c, 'command', side_effect=timeout), patch.object(Path, 'is_dir', return_value=True), patch.object(self.c.time, 'sleep'):
            self.c.work('start')
        self.assertIn('状态未知', self.c.JOB['error'])
        self.assertFalse(any('start' in args or 'stop' in args for args in self.calls))

    def test_stop_preserves_other_containers_and_failed_queries(self):
        self.config()
        for remaining in (result(json.dumps({'Names':'supabase_db_local-supabase-service'})),
                          result(ok=False, kind='timeout',code=None), result('not json'), result('{}')):
            self.calls.clear()
            self.c.JOB.update(error=None, steps=[])
            def other(args, timeout=8):
                if 'ps' in args and '--filter' not in args:
                    self.calls.append(args)
                    return remaining
                return self.fake(args, timeout)
            with patch.object(self.c, 'command', side_effect=other):
                self.c.work('stop')
            self.assertIn(self.c.supabase_args('stop'), self.calls)
            self.assertFalse(any(args[0].endswith('/colima') and 'stop' in args for args in self.calls))
            self.assertTrue(self.c.JOB['error'] or any('保留共享' in step['label'] for step in self.c.JOB['steps']))

    def test_stop_colima_only_after_no_running_containers(self):
        self.config()
        with patch.object(self.c, 'command', side_effect=self.fake):
            self.c.work('stop')
        supa = self.calls.index(self.c.supabase_args('stop'))
        docker = next(i for i, args in enumerate(self.calls) if 'ps' in args and '--filter' not in args)
        colima = next(i for i, args in enumerate(self.calls) if args[0].endswith('/colima') and 'stop' in args)
        self.assertLess(supa, docker)
        self.assertLess(docker, colima)

    def test_failed_stop_never_stops_shared_environment(self):
        self.config()
        def fail(args, timeout=8):
            if args[:2] == ['supabase','stop']:
                self.calls.append(args)
                return result(ok=False, detail='password=hidden')
            return self.fake(args, timeout)
        with patch.object(self.c, 'command', side_effect=fail):
            self.c.work('stop')
        self.assertNotIn('hidden', self.c.JOB['error'])
        self.assertFalse(any(args[0].endswith('/colima') and 'stop' in args for args in self.calls))


if __name__ == '__main__':
    unittest.main()
