import http.client
import importlib.util
import json
from pathlib import Path
import threading
import time
import unittest
from unittest.mock import patch


class HttpTest(unittest.TestCase):
    def setUp(self):
        spec=importlib.util.spec_from_file_location('control',Path(__file__).resolve().parents[1]/'scripts/service-control.py')
        self.c=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.c)
        self.server=self.c.ThreadingHTTPServer(('127.0.0.1',0),self.c.Handler)
        self.c.PORT=self.server.server_port
        self.host=f'127.0.0.1:{self.c.PORT}'
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
        self.c.LAST_PROBE=time.monotonic()
        self.c.SNAPSHOT['items']={key:dict(self.c.observation('unknown'),last_success=None) for key in self.c.IDS}

    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join(2)

    def request(self,path,method='GET',headers=None):
        client=http.client.HTTPConnection('127.0.0.1',self.c.PORT,timeout=2)
        client.request(method,path,body='{}' if method=='POST' else None,headers=headers or {})
        response=client.getresponse()
        result=(response.status,response.read(),dict(response.getheaders()))
        client.close()
        return result

    def test_status_json_and_fast_cache(self):
        with patch.object(self.c,'command',side_effect=AssertionError('No command on cached HTTP path')):
            code,body,headers=self.request('/api/status')
        self.assertEqual(code,200)
        self.assertEqual(json.loads(body)['project']['id'],'lemon-kids-local')
        self.assertEqual(headers['Cache-Control'],'no-store')

    def test_host_rejected(self):
        self.assertEqual(self.request('/api/status',headers={'Host':'evil.test'})[0],403)

    def test_post_origin_token_content_type_required(self):
        valid={'Origin':f'http://{self.host}','X-Control-Token':self.c.TOKEN,'Content-Type':'application/json'}
        for key in valid:
            headers=dict(valid);headers.pop(key)
            self.assertEqual(self.request('/api/start','POST',headers)[0],403)
        self.assertFalse(self.c.JOB['running'])

    def test_job_conflict(self):
        self.c.JOB['running']=True
        headers={'Origin':f'http://{self.host}','X-Control-Token':self.c.TOKEN,'Content-Type':'application/json'}
        self.assertEqual(self.request('/api/start','POST',headers)[0],409)
        self.assertEqual(self.request('/api/close','POST',headers)[0],409)

    def test_assets_csp_and_no_traversal(self):
        for path in ('/','/app.js','/style.css'):
            code,body,headers=self.request(path)
            self.assertEqual(code,200)
            self.assertIn("script-src 'self'",headers['Content-Security-Policy'])
        self.assertEqual(self.request('/../scripts/service-control.py')[0],404)

    def test_api_accepts_fixed_action_only(self):
        headers={'Origin':f'http://{self.host}','X-Control-Token':self.c.TOKEN,'Content-Type':'application/json'}
        self.assertEqual(self.request('/api/shell','POST',headers)[0],404)
        accepted=threading.Event()
        with patch.object(self.c,'work',side_effect=lambda action:accepted.set()):
            self.assertEqual(self.request('/api/start','POST',headers)[0],202)
            self.assertTrue(accepted.wait(1))


if __name__=='__main__': unittest.main()
