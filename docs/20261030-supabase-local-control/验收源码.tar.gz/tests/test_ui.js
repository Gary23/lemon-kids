const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
const path = require('path');
class Element {
  constructor() { this.children=[]; this.textContent=''; this.className=''; this.disabled=false; this.hidden=false; }
  replaceChildren() { this.children=[]; this.textContent=''; }
  append(...items) { this.children.push(...items); }
  addEventListener() {}
}
const elements = {};
const get = id => elements[id] || (elements[id] = new Element());
const ctx = vm.createContext({document:{getElementById:get, createElement:()=>new Element(),body:new Element()},
  console, setInterval:()=>{},setTimeout:()=>1,clearTimeout:()=>{},
  AbortController: class {constructor(){this.signal={};} abort(){}},
  fetch:()=>new Promise(()=>{}),assert});
vm.runInContext(fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8'),ctx);
function execute(code) { return vm.runInContext(code,ctx); }
execute(`token='test-token';
const success = {state:'running',checked_at:'2026-10-30T11:00:00+08:00'};
const data = {items:Object.fromEntries(ids.map(id=>[id,{...success,last_success:success,error:null,detail:''}])),
checking:false,checked_at:success.checked_at,containers_at:success.checked_at,containers_current:true,
containers:[{name:'db',status:'Up 2 minutes (healthy)',running:true,health:'healthy'}],
project:{id:'lemon-kids-local',studio:'http://127.0.0.1:54423',mail:'http://127.0.0.1:54424',api:'http://127.0.0.1:54421',database:'127.0.0.1:54422'},
job:{running:false,action:null,steps:[],error:null,finished_at:null}};
render(data);`);
assert.strictEqual(get('supabase').textContent,'就绪');
assert.strictEqual(get('start').disabled,true);
assert.strictEqual(get('stop').disabled,false);
assert.strictEqual(get('studio-link').href,'http://127.0.0.1:54423');
assert.strictEqual(get('mail-link').href,'http://127.0.0.1:54424');
assert.ok(get('addresses').textContent.includes('54421'));
execute(`data.items.supabase = {...data.items.supabase,state:'unknown',error:{kind:'timeout',message:'响应超时（8 秒）'}};
data.containers_current=false; render(data);`);
assert.strictEqual(get('supabase').textContent,'状态未知／响应超时');
assert.ok(get('supabase-history').textContent.includes('上次确认：就绪'));
assert.ok(get('container-note').textContent.includes('历史快照'));
assert.strictEqual(get('containers').children.length,1);
assert.strictEqual(get('containers').children[0].children[1].className,'pending');
assert.strictEqual(get('start').disabled,true);
assert.strictEqual(get('stop').disabled,true);
assert.ok(get('diagnostics').children[0].textContent.includes('响应超时'));
execute(`data.items.supabase = {...data.items.supabase,state:'stopped',error:null}; data.containers_current=true; render(data);`);
assert.strictEqual(get('supabase').textContent,'未运行');
assert.strictEqual(get('start').disabled,false);
assert.ok(get('diagnostics').children[0].textContent.includes('暂无查询错误'));
execute(`actionPending=true;render(data);`);
assert.strictEqual(get('start').disabled,true);
assert.strictEqual(get('close').disabled,true);
execute(`actionPending=false; disconnected(new Error('响应超时（10 秒）'));`);
assert.strictEqual(get('colima').textContent,'状态未知／响应超时');
assert.ok(get('colima-history').textContent.includes('上次确认：运行中'));
assert.strictEqual(get('containers').children.length,1);
assert.strictEqual(get('stop').disabled,true);
execute(`data.items.supabase = {...data.items.supabase,state:'running',error:null}; render(data);`);
assert.strictEqual(get('colima').textContent,'运行中');
assert.strictEqual(get('stop').disabled,false);
execute(`data.job={...data.job,action:'start',error:'旧操作失败',finished_at:'2026-10-30T10:00:00+08:00'};render(data);`);
assert.strictEqual(get('supabase').textContent,'就绪');
assert.strictEqual(get('job-error').textContent,'旧操作失败');
assert.ok(get('job-label').textContent.includes('10:00:00'));
execute(`lastData=null;disconnected(new Error('connection refused'));`);
assert.strictEqual(get('supabase').textContent,'状态未知');
assert.ok(get('diagnostics').textContent.includes('尚无成功查询记录'));
const html = fs.readFileSync(path.join(__dirname,'../web/index.html'),'utf8');
assert.ok(!/5432[1-4]/.test(html));
assert.ok(html.includes('Lemon Kids 容器'));
assert.ok(!/style=|onclick=/.test(html));
const source = fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8');
assert.ok(source.includes('controller.abort(), 10000'));
console.log('PASS: 前端状态、历史、恢复、断连、按钮互斥、项目入口与操作记录共 34 项断言');
