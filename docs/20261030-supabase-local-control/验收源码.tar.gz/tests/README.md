# 控制台测试

在项目根目录执行：

```sh
python3 -m unittest discover -s tests -v
node tests/test_ui.js
node --check web/app.js
python3 -m py_compile scripts/service-control.py
```

系统命令均使用模拟；HTTP 测试只监听本机临时端口，不启停真实服务、不写数据库。前端测试使用最小 DOM 验证状态呈现和按钮行为，页面视觉效果需人工核验。

模拟超时页面：

```sh
python3 tests/preview.py timeout
```

打开 `http://127.0.0.1:18765`；以 `Ctrl+C` 结束。模拟先建立成功历史，再让容器查询超时，用于检查“未知”、历史快照和错误诊断。省略 `timeout` 参数可预览正常状态。此预览内的系统命令也全部模拟。
