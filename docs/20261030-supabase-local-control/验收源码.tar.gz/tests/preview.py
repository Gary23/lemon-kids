"""Isolated preview: every system command is simulated, no live services touched."""
import importlib.util
import json
from pathlib import Path
import threading
import sys
spec=importlib.util.spec_from_file_location('control',Path(__file__).resolve().parents[1]/'scripts/service-control.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
c.PORT=18765
mode = sys.argv[1] if len(sys.argv)>1 else 'healthy'
def fake(args,timeout=8):
    if args == ['mount']:
        out=f'/dev/a on {c.DISK} (tuxera_ntfs)\n/dev/b on {c.RUNTIME} (hfs)'
    elif '--filter' in args:
        out='\n'.join(json.dumps({'Names':f'supabase_{name}_{c.PROJECT}','Status':'Up 2 minutes (healthy)'}) for name in c.EXPECTED)
        if mode == 'timeout':
            return {'ok':False,'code':None,'kind':'timeout','stdout':'','detail':'响应超时（8 秒）；模拟查询超时，未触碰真实服务'}
    else: out='28.0.0'
    return {'ok':True,'code':0,'kind':None,'stdout':out,'detail':''}
c.command=fake
c.probe_now()
if mode == 'timeout':
    mode='healthy';c.probe_now();mode='timeout';c.probe_now()
class PreviewHandler(c.Handler):
    def send_bytes(self, code, body, content_type):
        if content_type.startswith('text/html'):
            body=body.replace('Lemon Kids 本地服务控制台'.encode(), '模拟预览 · Lemon Kids 本地服务控制台'.encode())
        return super().send_bytes(code, body, content_type)

server=c.ThreadingHTTPServer((c.HOST,c.PORT),PreviewHandler)
print(f'Preview http://{c.HOST}:{c.PORT} ({mode})',flush=True)
server.serve_forever()
