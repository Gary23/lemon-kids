#!/usr/bin/env python3
"""Fixed-command, localhost-only controller for Lemon Kids Supabase."""

import copy
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent.parent
RUNTIME = Path('/Volumes/LemonKidsContainer')
DISK = Path('/Volumes/pan')
IMAGE = ROOT / 'container/LemonKidsContainer.sparsebundle'
PROJECT = 'lemon-kids-local'
WORKDIR = ROOT / 'apps/lemon-kids'
META = {'id': PROJECT, 'name': 'Lemon Kids', 'api': 'http://127.0.0.1:54421',
        'database': '127.0.0.1:54422', 'studio': 'http://127.0.0.1:54423',
        'mail': 'http://127.0.0.1:54424'}
HOST = '127.0.0.1'
PORT = 8765
TOKEN = secrets.token_urlsafe(32)
EXPECTED = ('db', 'kong', 'auth', 'rest', 'realtime', 'storage', 'studio',
            'inbucket', 'pg_meta', 'edge_runtime')
IDS = ('disk', 'image', 'colima', 'docker', 'supabase')
LOCK = threading.RLock()
PROBE_LOCK = threading.Lock()
JOB = {'running': False, 'action': None, 'steps': [], 'error': None, 'finished_at': None}
IDLE_SECONDS = 180
LAST_PAGE_REQUEST = time.monotonic()
REFRESH_SECONDS = 5
LAST_PROBE = 0
CHECKING = False


def now():
    return datetime.now().astimezone().isoformat(timespec='seconds')


def redact(value):
    value = value.decode(errors='replace') if isinstance(value, bytes) else str(value or '')
    value = re.sub(r'\x1b\[[0-9;]*[a-zA-Z]', '', value)
    value = re.sub(r'(?i)\b(?:postgres(?:ql)?|https?|wss?)://[^\s<>"\']+', '[连接地址已隐藏]', value)
    value = re.sub(r'\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b', '[令牌已隐藏]', value)
    value = re.sub(r'(?i)\bBearer\s+\S+', 'Bearer [已隐藏]', value)
    value = re.sub(r'''(?ix)(["']?[\w-]*(?:key|token|password|passwd|secret)[\w-]*["']?\s*[:=]\s*)(?:"[^"\n]*"|'[^'\n]*'|[^\s,;]+)''', r'\1[已隐藏]', value)
    value = re.sub(r'(?i)\bsb_(?:secret|publishable)_[\w-]+', '[密钥已隐藏]', value)
    return value[:1200]


def env():
    result = os.environ.copy()
    root = str(RUNTIME)
    result.update(COLIMA_HOME=f'{root}/colima', COLIMA_CACHE_HOME=f'{root}/cache',
                  LIMA_HOME=f'{root}/colima/_lima', DOCKER_CONFIG=f'{root}/docker-config',
                  DOCKER_HOST=f'unix://{root}/colima/default/docker.sock',
                  XDG_CACHE_HOME=f'{root}/xdg-cache', XDG_CONFIG_HOME=f'{root}/xdg-config',
                  XDG_DATA_HOME=f'{root}/xdg-data', TMPDIR=f'{root}/tmp/',
                  PATH=f'{root}/bin:{root}/lima/bin:{result.get("PATH", "")}')
    return result


def command(args, timeout=8):
    try:
        result = subprocess.run(args, cwd=ROOT,
                                env=os.environ.copy() if args[0] in ('mount', 'hdiutil') else env(),
                                timeout=timeout, capture_output=True, text=True)
        return {'ok': result.returncode == 0, 'code': result.returncode,
                'kind': None if result.returncode == 0 else 'exit',
                'stdout': result.stdout, 'detail': redact(result.stderr or result.stdout) or '命令未返回诊断信息'}
    except subprocess.TimeoutExpired as exc:
        return {'ok': False, 'code': None, 'kind': 'timeout', 'stdout': '',
                'detail': f'响应超时（{timeout} 秒）。' + redact(exc.stderr or exc.stdout)}
    except OSError as exc:
        return {'ok': False, 'code': None, 'kind': 'os', 'stdout': '', 'detail': redact(exc)}


def failure(result):
    code = f'退出码 {result["code"]}；' if result['code'] is not None else ''
    return {'kind': result['kind'], 'message': code + result['detail']}


def observation(state, detail='', error=None):
    return {'state': state, 'detail': redact(detail), 'error': error, 'checked_at': now()}


def failed(result):
    return observation('unknown', error=failure(result))


def parse_containers(output):
    found = {}
    for line in output.splitlines():
        if not line.strip():
            continue
        item = json.loads(line)
        if not isinstance(item, dict) or not isinstance(item.get('Names'), str) or not isinstance(item.get('Status'), str):
            raise ValueError('容器查询缺少 Names/Status 字段')
        match = re.fullmatch(rf'supabase_(.+)_{re.escape(PROJECT)}', item['Names'])
        if match:
            found[match.group(1)] = item['Status']
    rows = []
    for name in EXPECTED:
        status = found.get(name, '未创建')
        running = status.startswith('Up ') or status == 'Up'
        health = 'unhealthy' if '(unhealthy)' in status else ('starting' if '(health: starting)' in status else 'healthy' if '(healthy)' in status else None)
        rows.append({'name': name, 'status': redact(status), 'running': running, 'health': health})
    if any(row['health'] == 'unhealthy' or '(Paused)' in row['status'] or
           row['status'].startswith(('Restarting', 'Dead', 'Removal In Progress')) for row in rows):
        state = 'error'
    elif any(row['health'] == 'starting' for row in rows):
        state = 'starting'
    elif all(row['running'] for row in rows):
        state = 'running'
    elif any(row['running'] for row in rows):
        state = 'partial'
    else:
        state = 'stopped'
    return rows, state


def probe():
    """No mutations. Only confirmed observations may produce stopped."""
    items = {}
    mount = command(['mount'], 5)
    if mount['ok']:
        for key, path in (('disk', DISK), ('image', RUNTIME)):
            present = any(f' on {path} (' in line for line in mount['stdout'].splitlines())
            items[key] = observation('running' if present else 'stopped')
    else:
        items['disk'] = failed(mount)
        items['image'] = observation('unknown', error={'kind': 'dependency', 'message': '无法确认挂载状态：' + failure(mount)['message']})
    if items['disk']['state'] != 'running' or items['image']['state'] != 'running':
        unknown = any(items[key]['state'] == 'unknown' for key in ('disk', 'image'))
        for key in ('colima', 'docker', 'supabase'):
            items[key] = observation('unknown' if unknown else 'unavailable', '外接盘或运行映像未就绪',
                                     {'kind': 'dependency', 'message': '挂载状态未知，无法确认服务'} if unknown else None)
        return items, None
    colima = command([str(RUNTIME / 'bin/colima'), 'status'], 10)
    if colima['ok']:
        items['colima'] = observation('running')
    elif colima['kind'] == 'exit' and re.search(r'\bcolima is not running\b', colima['detail'], re.I):
        items['colima'] = observation('stopped', 'Colima 明确报告未运行')
    else:
        items['colima'] = failed(colima)
    docker = str(RUNTIME / 'bin/docker')
    # A direct Docker query may still succeed when the Colima status command fails.
    if items['colima']['state'] == 'stopped':
        items['docker'] = observation('unavailable', 'Colima 未运行')
    else:
        check = command([docker, 'info', '--format', '{{.ServerVersion}}'], 8)
        items['docker'] = observation('running') if check['ok'] else failed(check)
    if items['docker']['state'] != 'running':
        unknown = items['docker']['state'] == 'unknown'
        items['supabase'] = observation('unknown' if unknown else 'unavailable', 'Docker 未就绪',
                                        {'kind': 'dependency', 'message': 'Docker 状态未知，无法查询 Lemon Kids 容器'} if unknown else None)
        return items, None
    result = command([docker, 'ps', '-a', '--format', '{{json .}}',
                      '--filter', f'name=^supabase_.*_{PROJECT}$'], 8)
    if not result['ok']:
        items['supabase'] = failed(result)
        return items, None
    try:
        rows, state = parse_containers(result['stdout'])
        items['supabase'] = observation(state)
        return items, rows
    except (ValueError, KeyError, TypeError) as exc:
        items['supabase'] = observation('unknown', error={'kind': 'parse', 'message': '容器查询解析失败：' + redact(exc)})
        return items, None


SNAPSHOT = {'items': {key: dict(observation('checking'), last_success=None) for key in IDS},
            'containers': [], 'containers_at': None, 'containers_current': False, 'checked_at': None}


def probe_now():
    global SNAPSHOT, LAST_PROBE
    with PROBE_LOCK:
        try:
            items, rows = probe()
        except Exception as exc:
            items = {key: observation('unknown', error={'kind': 'internal', 'message': redact(exc)}) for key in IDS}
            rows = None
        with LOCK:
            for key, item in items.items():
                previous = SNAPSHOT['items'][key]['last_success']
                # Dependency-unavailable is not a direct observation of service state.
                item['last_success'] = ({k: item[k] for k in ('state', 'detail', 'checked_at')}
                                        if item['state'] not in ('unknown', 'checking', 'unavailable') else previous)
            SNAPSHOT = {'items': items, 'containers': rows if rows is not None else SNAPSHOT['containers'],
                        'containers_at': now() if rows is not None else SNAPSHOT['containers_at'],
                        'containers_current': rows is not None, 'checked_at': now()}
            LAST_PROBE = time.monotonic()
            return copy.deepcopy(SNAPSHOT)


def background_probe():
    global CHECKING
    try:
        probe_now()
    finally:
        with LOCK:
            CHECKING = False


def status():
    global CHECKING
    with LOCK:
        if not CHECKING and not JOB['running'] and (not LAST_PROBE or time.monotonic() - LAST_PROBE >= REFRESH_SECONDS):
            CHECKING = True
            threading.Thread(target=background_probe, daemon=True).start()
        return dict(copy.deepcopy(SNAPSHOT), checking=CHECKING, project=META.copy(), job=copy.deepcopy(JOB))


def update_step(label, state):
    with LOCK:
        JOB['steps'].append({'label': label, 'state': state, 'at': now()})


def run_step(label, args, timeout):
    update_step(label, '进行中')
    result = command(args, timeout)
    if not result['ok']:
        update_step(label, '失败')
        raise RuntimeError(f'{label}：{failure(result)["message"]}')
    update_step(label, '完成')


def validate_project():
    text = (WORKDIR / 'supabase/config.toml').read_text()
    match = re.search(r'^\s*project_id\s*=\s*["\']([^"\']+)["\']\s*(?:#.*)?$', text, re.M)
    if not match or match.group(1) != PROJECT:
        raise RuntimeError('Lemon Kids 配置的 project_id 不匹配，已拒绝启停')
    # Ports must agree with the fixed UI metadata as well as project identity.
    for section, port in (('api', 54421), ('db', 54422), ('studio', 54423), ('local_smtp', 54424)):
        block = re.search(rf'^\[{section}\]\s*\n(.*?)(?=^\[|\Z)', text, re.M | re.S)
        if not block or not re.search(rf'^port\s*=\s*{port}\s*(?:#.*)?$', block.group(1), re.M):
            raise RuntimeError(f'Lemon Kids {section} 端口配置不匹配，已拒绝启停')


def supabase_args(action):
    validate_project()
    return ['supabase', action, '--workdir', str(WORKDIR)] + (['--ignore-health-check'] if action == 'start' else [])


def certain(key, attempts=3):
    for attempt in range(attempts):
        snapshot = probe_now()
        item = snapshot['items'][key]
        if item['state'] not in ('unknown', 'checking'):
            return snapshot
        if attempt + 1 < attempts:
            time.sleep(1)
    error = item['error'] or {'message': '未能取得有效状态'}
    raise RuntimeError(f'{key} 状态未知；{error["message"]}。已停止本次操作，请稍后重试')


def work(action):
    try:
        validate_project()
        if action == 'start':
            current = certain('disk')
            if current['items']['disk']['state'] != 'running' or not IMAGE.is_dir():
                raise RuntimeError('外接盘未挂载在 /Volumes/pan，或运行映像不存在')
            update_step('检查外接盘和 Lemon Kids 配置', '完成')
            if current['items']['image']['state'] == 'stopped':
                run_step('挂载运行映像', ['hdiutil', 'attach', '-nobrowse', '-mountpoint', str(RUNTIME), str(IMAGE)], 120)
            elif current['items']['image']['state'] != 'running':
                raise RuntimeError('运行映像状态未知，已停止本次操作')
            current = certain('colima')
            if current['items']['colima']['state'] == 'stopped':
                run_step('启动 Colima', [str(RUNTIME / 'bin/colima'), 'start', '--activate=false'], 300)
            elif current['items']['colima']['state'] != 'running':
                raise RuntimeError('Colima 依赖未就绪，已停止本次操作')
            else:
                update_step('Colima 已运行', '完成')
            current = certain('docker')
            if current['items']['docker']['state'] != 'running':
                raise RuntimeError('Docker 尚未就绪，请稍后重试')
            current = certain('supabase')
            if current['items']['supabase']['state'] == 'running':
                update_step('Lemon Kids Supabase 已就绪', '完成')
            else:
                run_step('启动 Lemon Kids Supabase', supabase_args('start'), 900)
                update_step('启动命令已完成，容器健康状态以查询结果为准', '完成')
        else:
            current = certain('colima')
            if current['items']['colima']['state'] in ('stopped', 'unavailable'):
                update_step('共享运行环境未就绪，无需停止', '完成')
                return
            current = certain('supabase')
            if current['items']['docker']['state'] != 'running':
                raise RuntimeError('无法确认 Docker，保留共享运行环境')
            if any(row['running'] or row['status'].startswith(('Restarting', 'Paused')) for row in current['containers']):
                run_step('停止 Lemon Kids Supabase（保留数据）', supabase_args('stop'), 300)
            else:
                update_step('Lemon Kids Supabase 未运行', '完成')
            other = command([str(RUNTIME / 'bin/docker'), 'ps', '--format', '{{json .}}'], 8)
            if not other['ok']:
                raise RuntimeError('无法确认剩余运行容器，已保留 Colima；' + failure(other)['message'])
            try:
                running = [json.loads(line) for line in other['stdout'].splitlines() if line.strip()]
                if any(not isinstance(row.get('Names'), str) for row in running):
                    raise ValueError('缺少容器名称')
            except (ValueError, TypeError, AttributeError) as exc:
                raise RuntimeError('剩余容器查询解析失败，已保留 Colima；' + redact(exc))
            if running:
                update_step(f'仍有 {len(running)} 个运行容器，保留共享 Colima', '完成')
            else:
                run_step('停止共享 Colima', [str(RUNTIME / 'bin/colima'), 'stop'], 180)
    except Exception as exc:
        with LOCK:
            JOB['error'] = redact(exc)
    finally:
        probe_now()
        with LOCK:
            JOB['running'] = False
            JOB['finished_at'] = now()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def allowed_host(self):
        return self.headers.get('Host') == f'{HOST}:{PORT}'

    def send_bytes(self, code, body, content_type):
        self.send_response(code)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, code, obj):
        self.send_bytes(code, json.dumps(obj, ensure_ascii=False).encode(), 'application/json; charset=utf-8')

    def do_GET(self):
        if not self.allowed_host():
            return self.send_json(403, {'error': '仅允许本机访问'})
        path = urlsplit(self.path).path
        if path == '/api/health':
            return self.send_json(200, {'app': 'local-supabase-control', 'version': 2, 'project': PROJECT})
        if path == '/api/status':
            global LAST_PAGE_REQUEST
            with LOCK:
                LAST_PAGE_REQUEST = time.monotonic()
            try:
                return self.send_json(200, status())
            except Exception:
                return self.send_json(500, {'error': '状态检查失败'})
        if path == '/api/token':
            return self.send_json(200, {'token': TOKEN})
        if path == '/':
            path = '/index.html'
        if path in ('/index.html', '/app.js', '/style.css'):
            mime = 'text/html' if path.endswith('.html') else ('text/javascript' if path.endswith('.js') else 'text/css')
            return self.send_bytes(200, (ROOT / 'web' / path[1:]).read_bytes(), mime + '; charset=utf-8')
        self.send_json(404, {'error': '未找到页面'})

    def do_POST(self):
        if not self.allowed_host() or self.headers.get('Origin') != f'http://{HOST}:{PORT}' or \
                self.headers.get('X-Control-Token') != TOKEN or \
                self.headers.get('Content-Type') != 'application/json':
            return self.send_json(403, {'error': '请求未获授权'})
        path = urlsplit(self.path).path
        if path == '/api/close':
            with LOCK:
                if JOB['running']:
                    return self.send_json(409, {'error': '服务操作正在进行，请完成后再关闭控制台'})
            self.send_json(200, {'closed': True})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return
        action = {'/api/start': 'start', '/api/stop': 'stop'}.get(path)
        if not action:
            return self.send_json(404, {'error': '未知操作'})
        with LOCK:
            if JOB['running']:
                return self.send_json(409, {'error': '已有操作正在进行'})
            JOB.update(running=True, action=action, steps=[], error=None, finished_at=None)
        threading.Thread(target=work, args=(action,), daemon=True).start()
        self.send_json(202, {'accepted': True})


def idle_watch(server):
    while True:
        time.sleep(10)
        with LOCK:
            should_stop = not JOB['running'] and time.monotonic() - LAST_PAGE_REQUEST >= IDLE_SECONDS
        if should_stop:
            server.shutdown()
            return


if __name__ == '__main__':
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    threading.Thread(target=idle_watch, args=(server,), daemon=True).start()
    print(f'本地服务控制页面：http://{HOST}:{PORT}', flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()
