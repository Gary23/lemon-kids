# Lemon Kids 独立本地 Supabase

项目 ID：`lemon-kids-local`。API `54421`、Postgres `54422`、Studio `54423`、邮件界面 `54424`；影子库 `54420`，Edge inspector `8184`。与通用项目 `local-supabase-service` 使用不同项目 ID、容器和 Docker 卷。设备只应访问 API 端口。

## 本地控制台与启停

双击服务根目录的 `打开本地服务控制台.command`，在 `http://127.0.0.1:8765/` 管理本项目。控制台的启动、Supabase 停止命令、状态和入口均指向 `lemon-kids-local`，不会启动通用项目。停止本项目时保留数据；仍有其他运行容器或无法确认时保留共享 Colima。查询超时显示未知并保留带时间的历史状态，不表示服务已停止。

控制台约三分钟没有页面状态请求会空闲退出；重新双击入口可恢复，数据库服务不受控制台退出影响。完整说明见[本地控制台使用说明](../../本地控制台-使用说明.md)。

在服务根目录，挂载两个外接盘路径后也可通过命令行运行：

```sh
. ./container/env.sh
supabase start --workdir apps/lemon-kids --ignore-health-check
docker ps --format '{{.Names}} {{.Status}}'
supabase stop --workdir apps/lemon-kids
```

重启时确认所有 `lemon-kids-local` 核心容器实际变为 healthy。`supabase status --workdir apps/lemon-kids -o env` 可取得本机公开客户端 key；其输出包含高权限密钥，切勿复制到日志、文档或客户端。外接盘剩余空间与局域网端口暴露需在每次新设备测试前核对。

## 当前数据范围

已在专用空库按顺序执行 Lemon Kids 仓库的 `supabase/sql/20261022_local_core_baseline.sql`、`20261022_local_private_storage.sql`、`20261022_local_tasks_baseline.sql`、`20261022_local_parent_onboarding.sql`。最后一份迁移为家长注册、建家庭提供受限 RPC，并保护用户角色、家庭和积分。覆盖合成家庭、家长与孩子、绑定码 RPC、基础任务读写和按家庭路径隔离的私有测试对象。验证命令：

```sh
. ./container/env.sh
python3 scripts/verify-lemon-kids.py write
python3 scripts/verify-lemon-kids-parent.py
# 仅重启专用项目，等核心容器健康
python3 scripts/verify-lemon-kids.py read
python3 scripts/verify-service.py read
```

历史 SQL 逐文件初筛见 Lemon Kids 仓库 `supabase/LOCAL_REVIEW.md`。当前四份基线仅支持数据服务的核心合成验证和家长注册建家庭，**尚不是五个 Android 应用的完整 schema**；各业务域迁移、加入家庭、其他 Storage bucket、Edge Function 和外部 SCF 须随对应应用流程审核。合成验证脚本使用本地 Auth 创建账号；只在本地 VM 的临时目录保存不含密钥的读回标识。

## 客户端接入清单

### 家长端本地演示数据

容器和 `lemon-kids-local` 已启动后，在通用服务根目录执行：

```sh
. ./container/env.sh
python3 scripts/seed-lemon-kids-parent.py
python3 scripts/seed-lemon-kids-parent.py show-login
```

脚本只连接本机 `127.0.0.1:54421` 的专用项目，创建一组可重复使用的合成家长账号、家庭、孩子、任务绑定码和三条基础任务。演示账号为 `demo@local.test`，密码为 `12345678`，仅用于本地调试。登录信息保存在运行映像 `/Volumes/LemonKidsContainer/tmp/lemon-kids-parent-demo.json`；`show-login` 会在本机终端显示。重复运行只补齐缺失数据，不覆盖已有任务。当前本地库仍只支持核心结构和基础任务，其余业务页可能依赖尚未迁移的表。

| 应用 | 模拟器 API 地址 | 真机 API 地址 | 当前状态 |
| --- | --- | --- | --- |
| `parent-app` | `http://10.0.2.2:54421` | `http://<宿主机局域网地址>:54421` | 显式本地 debug、家长注册建家庭及自动测试已通过；待设备安装和人工验收 |
| `kid-task-app` | 同上 | 同上 | 待独立流程与任务域验证 |
| `kid-monitor-app` | 同上 | 同上 | 待独立流程与闹钟域验证 |
| `kid-literacy-app` | 同上 | 同上 | 待独立流程与认字域/外部函数验证 |
| `family-video-app` | 同上 | 同上 | 待独立流程与视频域/Edge Function 验证 |

家长端本地构建示例（在 Lemon Kids 仓库执行）：

```sh
export LEMON_KIDS_LOCAL_SUPABASE_URL=http://10.0.2.2:54421
# 从 `supabase status --workdir apps/lemon-kids -o env` 读取 ANON_KEY，赋给以下环境变量；不要写入版本库。
export LEMON_KIDS_LOCAL_SUPABASE_ANON_KEY=<本项目公开客户端 key>
./gradlew :parent-app:assembleDebug -PlocalSupabase=true
```

也可在未提交的 `local.properties` 中写入 `localSupabaseUrl` 和 `localSupabaseAnonKey`。没有 `-PlocalSupabase=true` 的 debug 及 release 均保持线上；本地 debug 的 application ID 增加 `.local` 后缀，避免与线上会话混用。共享客户端与三个绑定码 RPC 使用同一构建配置。`family-video-app` 独立函数地址尚待其应用流程处理；家长其他业务页所需 schema 也尚未迁移。尚未进行设备连接与人工验收。
