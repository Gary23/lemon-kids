const ids = ['disk', 'image', 'colima', 'docker', 'supabase'];
const names = {db:'PostgreSQL',kong:'API 网关',auth:'Auth',rest:'REST',realtime:'Realtime',storage:'Storage',studio:'Studio',inbucket:'邮件测试',pg_meta:'Postgres Meta',edge_runtime:'Edge Runtime'};
const labels = {checking:'检查中',running:'运行中',stopped:'未运行',unavailable:'依赖未就绪',unknown:'状态未知',starting:'启动中',partial:'部分运行',error:'异常'};
let token = '';
let busy = false;
let checking = false;
let closed = false;
let lastData = null;
let actionPending = false;
const node = id => document.getElementById(id);
const stamp = value => value ? value.replace('T', ' ') : '暂无';

function label(id, item) {
  if (item.state === 'unknown' && item.error && item.error.kind === 'timeout') return '状态未知／响应超时';
  if (id === 'supabase' && item.state === 'running') return '就绪';
  if (['disk', 'image'].includes(id)) {
    if (item.state === 'running') return '已挂载';
    if (item.state === 'stopped') return '未挂载';
  }
  return labels[item.state] || '状态未知';
}

function render(data, disconnected = false) {
  lastData = data;
  ids.forEach(id => {
    const item = data.items[id];
    node(id).textContent = label(id, item);
    node(id).className = item.state === 'running' ? 'ok' : ['stopped','error','partial'].includes(item.state) ? 'bad' : 'pending';
    const previous = item.last_success;
    node(`${id}-history`).textContent = previous ? `上次确认：${label(id, previous)} · ${stamp(previous.checked_at)}` : '尚无成功查询记录';
  });
  node('updated').textContent = `${data.checking ? '正在刷新 · ' : ''}本次检查：${stamp(data.checked_at)}`;
  const diagnosis = node('diagnostics');
  diagnosis.replaceChildren();
  for (const id of ids) {
    const item = data.items[id];
    if (!item.error && !item.detail) continue;
    const p = document.createElement('p');
    p.textContent = `${id} · ${stamp(item.checked_at)}：${item.error ? item.error.message : item.detail}`;
    diagnosis.append(p);
  }
  if (!diagnosis.children.length) {
    const p = document.createElement('p');
    p.textContent = '暂无查询错误。查询结果与下方启停操作记录分别显示。';
    diagnosis.append(p);
  }
  node('container-note').textContent = data.containers_current ? `Lemon Kids · ${stamp(data.containers_at)}` :
    data.containers_at ? `历史快照 · ${stamp(data.containers_at)}（本次未能确认，以下不代表当前状态）` : '尚无成功容器查询记录';
  const container = node('containers');
  container.replaceChildren();
  for (const item of data.containers) {
    const row = document.createElement('div');
    row.className = 'container';
    const title = document.createElement('span');
    title.textContent = names[item.name] || item.name;
    const detail = document.createElement('small');
    detail.textContent = item.status;
    detail.className = !data.containers_current ? 'pending' : item.health === 'starting' ? 'pending' : item.running && item.health !== 'unhealthy' ? 'ok' : 'bad';
    row.append(title, detail);
    container.append(row);
  }
  if (!data.containers.length) {
    const p = document.createElement('p');
    p.textContent = '等待取得 Lemon Kids 容器状态；查询失败不表示服务未运行。';
    container.append(p);
  }
  busy = data.job.running || actionPending;
  const uncertain = disconnected || ids.some(id => ['unknown', 'checking'].includes(data.items[id].state));
  node('start').disabled = busy || uncertain || !token || data.items.disk.state !== 'running' || data.items.supabase.state === 'running';
  node('stop').disabled = busy || uncertain || !token || data.items.colima.state !== 'running';
  node('close').disabled = busy || disconnected || !token;
  node('job-label').textContent = data.job.running ? '执行中…' : data.job.action ?
    `${data.job.action === 'start' ? '启动' : '停止'}${data.job.error ? '失败' : '结束'} · ${stamp(data.job.finished_at)}` : '暂无操作';
  node('job-error').hidden = !data.job.error;
  node('job-error').textContent = data.job.error || '';
  const steps = node('steps');
  steps.replaceChildren();
  const entries = data.job.steps.length ? data.job.steps : [{label:'启停仅管理 Lemon Kids Supabase。',state:''}];
  for (const entry of entries) {
    const li = document.createElement('li');
    li.textContent = entry.state ? `${entry.label}：${entry.state}` : entry.label;
    steps.append(li);
  }
  node('studio-link').href = data.project.studio;
  node('mail-link').href = data.project.mail;
  node('addresses').textContent = `API：${data.project.api}　数据库：${data.project.database}　项目：${data.project.id}`;
}

async function request(url, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);
  try {
    const response = await fetch(url, {...options, cache:'no-store', signal:controller.signal});
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || `请求失败（HTTP ${response.status}）`);
    return result;
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('响应超时（10 秒）');
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function disconnected(error) {
  if (lastData) {
    const data = JSON.parse(JSON.stringify(lastData));
    for (const id of ids) {
      data.items[id] = {...data.items[id], state:'unknown', checked_at:new Date().toISOString(),
        error:{kind:error.message.includes('超时') ? 'timeout' : 'connection',message:`控制台连接失败：${error.message}`}};
    }
    data.checking = false;
    data.containers_current = false;
    render(data, true);
  } else {
    ids.forEach(id => { node(id).textContent = '状态未知'; node(id).className = 'pending'; });
    ['start','stop','close'].forEach(id => {node(id).disabled = true;});
    node('diagnostics').textContent = `控制台连接失败：${error.message}。尚无成功查询记录。`;
  }
  node('updated').textContent = `无法连接控制程序：${error.message}。可重新双击“打开本地服务控制台.command”。`;
}

async function refresh() {
  if (checking || closed) return;
  checking = true;
  try {
    // Reacquire after a controller restart or an initial token request failure.
    token = (await request('/api/token')).token;
    const data = await request('/api/status');
    if (!closed) render(data);
  } catch (error) {
    if (!closed) disconnected(error);
  } finally {
    checking = false;
  }
}

async function act(action) {
  if (busy || closed) return;
  actionPending = true;
  busy = true;
  ['start','stop','close'].forEach(id => {node(id).disabled = true;});
  try {
    await request(`/api/${action}`, {method:'POST', headers:{'Content-Type':'application/json','X-Control-Token':token}, body:'{}'});
    actionPending = false;
    await refresh();
  } catch (error) {
    actionPending = false;
    await refresh();
    node('job-error').hidden = false;
    node('job-error').textContent = `操作请求：${error.message}。请查看执行进度确认是否已开始。`;
  }
}

async function closeControl() {
  if (busy || closed) return;
  try {
    await request('/api/close', {method:'POST', headers:{'Content-Type':'application/json','X-Control-Token':token}, body:'{}'});
    closed = true;
    document.body.innerHTML = '<main><header><h1>控制台已关闭</h1><p>可以关闭此标签页。Docker 和 Supabase 保持原有运行状态。</p></header></main>';
  } catch (error) {
    node('job-error').hidden = false;
    node('job-error').textContent = error.message;
  }
}

node('start').addEventListener('click', () => act('start'));
node('stop').addEventListener('click', () => act('stop'));
node('close').addEventListener('click', closeControl);
refresh();
setInterval(refresh, 5000);
